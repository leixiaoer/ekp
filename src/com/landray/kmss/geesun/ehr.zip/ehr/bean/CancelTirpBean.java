package com.landray.kmss.geesun.ehr.bean;

/*
 *文件名: BackFromLeaveBean
 *创建者: zgf
 *描述: 出差单作废 bean
 */
public class CancelTirpBean {

    private String code;


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
