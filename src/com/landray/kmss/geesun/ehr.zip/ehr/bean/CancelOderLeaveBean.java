package com.landray.kmss.geesun.ehr.bean;

/*
 *文件名: BackFromLeaveBean
 *创建者: zgf
 *描述: 请假单作废接口 bean
 */
public class CancelOderLeaveBean {
    private String code;


    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
}
