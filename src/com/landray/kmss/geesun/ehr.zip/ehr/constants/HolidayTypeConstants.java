package com.landray.kmss.geesun.ehr.constants;

public class HolidayTypeConstants {
   public static String LEAVE_CATEGORY_NUM_SJ = "4";
   
}
